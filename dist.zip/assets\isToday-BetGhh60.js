import{c as s,s as a}from"./es-5sDajNw9.js";function c(t){return s(t,Date.now())}function e(t,r){const n=a(t),o=a(r);return+n==+o}function i(t){return e(t,c(t))}export{i as a,c,e as i};
