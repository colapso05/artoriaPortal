import{a as r}from"./addDays-0bu_8E5G.js";function t(a,s){return r(a,-s)}export{t as s};
